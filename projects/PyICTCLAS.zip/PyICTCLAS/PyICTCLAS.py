# -*- coding: cp936 -*-
from ctypes import *

class ICTCLAS:
        #(POS_NONE, ICT_POS_SECOND, ICT_POS_FIRST, PKU_MAP_SECOND, PKU_MAP_FIRST) = (-1,0,1,2,3)

        def __init__(self):
                self.dll = cdll.LoadLibrary('ICTCLAS30.dll')
                self.dll.ICTCLAS_Init(c_char_p('.'))
                self.bTag = False

        def __del__(self):
                self.dll.ICTCLAS_Exit()

        def setPos(self, pos):
                if pos in range(4):
                        self.bTag = True
                        self.dll.ICTCLAS_SetPOSmap(pos)
                else:
                        self.bTag = False
                
        def paragraphProcess(self, para):
                if self.bTag:
                        bSuc = self.dll.ICTCLAS_ParagraphProcess(c_char_p(para),1)
                else:
                        bSuc = self.dll.ICTCLAS_ParagraphProcess(c_char_p(para),0)
                return c_char_p(bSuc).value
                        
        def fileProcess(self, src, res):
                if self.bTag:
                        self.dll.ICTCLAS_FileProcess(c_char_p(src),c_char_p(res),1)
                else:
                        self.dll.ICTCLAS_FileProcess(c_char_p(src),c_char_p(res),0)

        def importUserDict(self, path):
                for line in file(path):
                        self.dll.ICTCLAS_AddUserWord(c_char_p(line.strip()))   

        def addUserWord(self, word):
                self.dll.ICTCLAS_AddUserWord(c_char_p(word))

        def delUserWord(self, word):
                self.dll.ICTCLAS_DelUsrWord(c_char_p(word))

        def saveUserDict(self):
                self.dll.ICTCLAS_SaveTheUsrDic()
