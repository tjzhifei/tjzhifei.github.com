# -*- coding: cp936 -*-
from  PyICTCLAS import ICTCLAS

split = ICTCLAS()
split.setPos(1)
split.fileProcess('test.txt','test_res1.txt')
split.importUserDict('userdict.txt')
#split.saveUserDict() 
split.fileProcess('test.txt','test_res2.txt')

